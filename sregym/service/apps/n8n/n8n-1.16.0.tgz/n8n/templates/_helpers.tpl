{{/*
Expand the name of the chart.
*/}}
{{- define "n8n.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this.
*/}}
{{- define "n8n.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default "n8n" .Values.nameOverride }}
{{- if or (contains "n8n" .Release.Name) (eq .Release.Name "n8n") }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "n8n.labels" -}}
helm.sh/chart: {{ include "n8n.chart" . }}
{{ include "n8n.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Pod template labels. podLabels intentionally wins over commonLabels for
user-defined keys on pods only; chart-managed selector/identity labels are
always set by the chart.
*/}}
{{- define "n8n.podLabels" -}}
{{- $root := .root -}}
{{- $component := .component -}}
{{- $labels := dict -}}
{{- range $k, $v := ($root.Values.commonLabels | default dict) -}}
{{- $_ := set $labels $k $v -}}
{{- end -}}
{{- $_ := set $labels "helm.sh/chart" (include "n8n.chart" $root) -}}
{{- $_ := set $labels "app.kubernetes.io/name" (include "n8n.name" $root) -}}
{{- $_ := set $labels "app.kubernetes.io/instance" $root.Release.Name -}}
{{- if $root.Chart.AppVersion -}}
{{- $_ := set $labels "app.kubernetes.io/version" $root.Chart.AppVersion -}}
{{- end -}}
{{- $_ := set $labels "app.kubernetes.io/managed-by" $root.Release.Service -}}
{{- $_ := set $labels "app.kubernetes.io/component" $component -}}
{{- range $k, $v := ($root.Values.podLabels | default dict) -}}
{{- $_ := set $labels $k $v -}}
{{- end -}}
{{- toYaml $labels -}}
{{- end -}}

{{/*
Pod securityContext for a role (main, worker, webhookProcessor). A role's
podSecurityContext block replaces the chart-wide securityContext for that
role, so the block is rendered exactly as written.
*/}}
{{- define "n8n.podSecurityContext" -}}
{{- $root := .root -}}
{{- $override := index ($root.Values.podSecurityContext | default dict) .role -}}
{{- if $override -}}
{{- toYaml $override -}}
{{- else if $root.Values.securityContext.enabled -}}
fsGroup: {{ $root.Values.securityContext.fsGroup }}
runAsUser: {{ $root.Values.securityContext.runAsUser }}
runAsGroup: {{ $root.Values.securityContext.runAsGroup }}
runAsNonRoot: true
seccompProfile:
  type: RuntimeDefault
{{- end -}}
{{- end -}}

{{/*
Container securityContext for a role (main, worker, webhookProcessor,
taskRunner). The defaults live in values.yaml, so Helm merges user values over
them and a null removes a field. helm upgrade --reuse-values renders with the
previous chart's values.yaml, which may have no entry for the role, so the
hardened default is rendered when the role is missing.
*/}}
{{- define "n8n.containerSecurityContext" -}}
{{- $roles := .root.Values.containerSecurityContext | default dict -}}
{{- if hasKey $roles .role -}}
{{- with index $roles .role -}}
{{- toYaml . -}}
{{- end -}}
{{- else -}}
allowPrivilegeEscalation: false
capabilities:
  drop:
    - ALL
{{- end -}}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "n8n.selectorLabels" -}}
app.kubernetes.io/name: {{ include "n8n.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Chart name and version
*/}}
{{- define "n8n.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{/*
n8n image tag. Falls back to the chart's appVersion when image.tag is unset,
so a chart release always pins the n8n version it was built against.
*/}}
{{- define "n8n.imageTag" -}}
{{- default .Chart.AppVersion .Values.image.tag -}}
{{- end -}}

{{/*
Task runner image tag. Resolves taskRunners.image.tag, then image.tag, then
appVersion, so the sidecar tracks the n8n image unless deliberately overridden.
*/}}
{{- define "n8n.taskRunnerImageTag" -}}
{{- default (include "n8n.imageTag" .) .Values.taskRunners.image.tag -}}
{{- end -}}

{{/*
n8n image reference. A digest, when set, replaces the tag, so the image is
pinned by content and nothing is resolved by tag at pull time.
*/}}
{{- define "n8n.image" -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository (include "n8n.imageTag" .) -}}
{{- end -}}
{{- end -}}

{{/*
Task runner image reference. Takes only taskRunners.image.digest: the runner is
a different image, so the n8n digest can never apply to it.
*/}}
{{- define "n8n.taskRunnerImage" -}}
{{- if .Values.taskRunners.image.digest -}}
{{- printf "%s@%s" .Values.taskRunners.image.repository .Values.taskRunners.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.taskRunners.image.repository (include "n8n.taskRunnerImageTag" .) -}}
{{- end -}}
{{- end -}}

{{/*
Task-runner sidecar container, shared by the main pod (standalone) and worker
pods (queue mode) so both sidecars stay the same.
*/}}
{{- define "n8n.taskRunnerContainer" -}}
- name: task-runner
  image: {{ include "n8n.taskRunnerImage" . | quote }}
  imagePullPolicy: {{ .Values.taskRunners.image.pullPolicy }}
  {{- with include "n8n.containerSecurityContext" (dict "root" . "role" "taskRunner") }}
  securityContext:
    {{- . | nindent 4 }}
  {{- end }}
  env:
    {{- include "n8n.taskRunnerSidecarEnv" . | nindent 4 }}
  resources:
    {{- toYaml .Values.taskRunners.resources | nindent 4 }}
  {{- $probes := .Values.taskRunners.probes | default dict }}
  {{- $port := include "n8n.taskRunnerHealthCheckPort" . }}
  {{- if $port }}
  {{- /* The launcher answers this itself, so a runner busy with a long task
  does not fail it. The launcher restarts unhealthy runners on its own. */}}
  {{- with $probes.liveness }}
  {{- if .enabled }}
  livenessProbe:
    {{- include "n8n.taskRunnerProbe" (dict "probe" . "port" $port) | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
  {{- if .Values.taskRunners.customConfig.enabled }}
  volumeMounts:
    - name: task-runner-config
      mountPath: /etc/n8n-task-runners.json
      subPath: {{ .Values.taskRunners.customConfig.configMapKey }}
      readOnly: true
  {{- end }}
{{- end -}}

{{/*
Port of the launcher's health endpoint in the task-runner sidecar. The launcher
reads N8N_RUNNERS_LAUNCHER_HEALTH_CHECK_PORT, so the probe follows it when
taskRunners.extraEnv sets it, and use the launcher's default otherwise. Empty
when it comes from valueFrom, which the chart cannot read, so the probe is
left out rather than pointed at the wrong port.
*/}}
{{- define "n8n.taskRunnerHealthCheckPort" -}}
{{- $port := "5680" -}}
{{- range .Values.taskRunners.extraEnv -}}
{{- if eq (.name | default "") "N8N_RUNNERS_LAUNCHER_HEALTH_CHECK_PORT" -}}
{{- $port = .value | default "" | toString -}}
{{- end -}}
{{- end -}}
{{- $port -}}
{{- end -}}

{{/*
A task-runner sidecar probe against the launcher's health endpoint.
*/}}
{{- define "n8n.taskRunnerProbe" -}}
httpGet:
  path: {{ .probe.path }}
  port: {{ .port }}
initialDelaySeconds: {{ .probe.initialDelaySeconds }}
periodSeconds: {{ .probe.periodSeconds }}
timeoutSeconds: {{ .probe.timeoutSeconds }}
failureThreshold: {{ .probe.failureThreshold }}
{{- end -}}

{{/*
Render one extraObjects entry through tpl and return it as YAML. A string
entry is rendered as written; a map entry is serialised first, so both can
reference the release. A literal `{{` has to be written as `{{ "{{" }}`.

Call with (dict "root" $ "object" <entry>).
*/}}
{{- define "n8n.extraObject" -}}
{{- if typeIs "string" .object -}}
{{- tpl .object .root -}}
{{- else -}}
{{- tpl (toYaml .object) .root -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "n8n.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "n8n.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- .Values.serviceAccount.name }}
{{- end }}
{{- end -}}

{{/*
Validate values. Called once from deployment-main.yaml to fail on bad config.
Every check adds its message to $errs instead of failing on the spot, so one
render reports every problem rather than making the user fix and re-run once
per mistake.
*/}}
{{- define "n8n.validate" -}}
{{- $errs := list -}}

{{/* --- Queue mode infrastructure --- */}}
{{- if .Values.queueMode.enabled -}}
{{- if not .Values.database.useExternal -}}
{{- $errs = append $errs "database.useExternal must be true when queueMode.enabled=true. Queue mode requires external PostgreSQL." -}}
{{- end -}}
{{- if not .Values.database.host -}}
{{- $errs = append $errs "database.host is required when queueMode.enabled=true. Set it to your PostgreSQL hostname." -}}
{{- end -}}
{{- if not .Values.redis.enabled -}}
{{- $errs = append $errs "redis.enabled must be true when queueMode.enabled=true. Queue mode requires Redis." -}}
{{- end -}}
{{- if not .Values.redis.host -}}
{{- $errs = append $errs "redis.host is required when queueMode.enabled=true. Set it to your Redis hostname." -}}
{{- end -}}
{{- end -}}

{{/* --- Standalone mode constraints --- */}}
{{- if not .Values.queueMode.enabled -}}
{{- if and (not .Values.persistence.enabled) (not .Values.database.useExternal) -}}
{{- $errs = append $errs "persistence.enabled must be true when queueMode.enabled=false and database.useExternal=false. Standalone mode requires persistent storage when no external database." -}}
{{- end -}}
{{- if .Values.multiMain.enabled -}}
{{- $errs = append $errs "multiMain.enabled=true requires queueMode.enabled=true" -}}
{{- end -}}
{{- if .Values.webhookProcessor.enabled -}}
{{- $errs = append $errs "webhookProcessor.enabled=true requires queueMode.enabled=true" -}}
{{- end -}}
{{- end -}}

{{/* --- Webhook processor --- */}}
{{- if and .Values.ingress.webhookProcessor.enabled (not .Values.webhookProcessor.enabled) -}}
{{- $errs = append $errs "ingress.webhookProcessor.enabled=true requires webhookProcessor.enabled=true" -}}
{{- end -}}

{{/* --- KEDA --- */}}
{{- if and .Values.keda.enabled .Values.queueMode.enabled .Values.keda.webhookProcessor.enabled .Values.webhookProcessor.enabled (not .Values.keda.webhookProcessor.triggers) -}}
{{- $errs = append $errs "keda.webhookProcessor.triggers is required when keda.webhookProcessor.enabled=true. KEDA rejects a ScaledObject with no triggers, so nothing would autoscale webhook processors. Add a trigger, or set keda.webhookProcessor.enabled=false to hold them at webhookProcessor.replicaCount." -}}
{{- end -}}

{{/* --- Multi-main --- */}}
{{- if and .Values.multiMain.enabled (lt (int .Values.multiMain.replicas) 2) -}}
{{- $errs = append $errs "multiMain.enabled=true requires multiMain.replicas >= 2" -}}
{{- end -}}
{{- if and .Values.multiMain.enabled (not .Values.license.enabled) -}}
{{- $errs = append $errs "multiMain.enabled=true requires license.enabled=true. Multi-main is an n8n Enterprise feature. Set license.activationKey or license.existingSecret.name, or set license.enabled=true alone if the licence reaches n8n another way." -}}
{{- end -}}
{{/* Mains only coordinate in multi-main; without it, every main acts as leader and the instance splits. */}}
{{- if and (gt (int .Values.replicaCount) 1) (not .Values.multiMain.enabled) -}}
{{- $errs = append $errs "replicaCount > 1 requires multiMain.enabled=true. Without multi-main, each extra main runs schedules and triggers on its own. Set multiMain.enabled=true, or set replicaCount to 1." -}}
{{- end -}}
{{- if and .Values.hpa.main.enabled (gt (int .Values.hpa.main.maxReplicas) 1) (not .Values.multiMain.enabled) -}}
{{- $errs = append $errs "hpa.main.enabled=true with hpa.main.maxReplicas > 1 requires multiMain.enabled=true. Without multi-main, each extra main runs schedules and triggers on its own. Set multiMain.enabled=true, or set hpa.main.enabled=false." -}}
{{- end -}}

{{/* --- Database TLS from an existing Secret --- */}}
{{- $ssl := .Values.database.ssl -}}
{{- $sslSecret := $ssl.existingSecret | default dict -}}
{{- $sslSecretKeys := or $sslSecret.caKey $sslSecret.certKey $sslSecret.keyKey -}}
{{- if and $sslSecret.name (not $sslSecretKeys) -}}
{{- $errs = append $errs "database.ssl.existingSecret.name is set but no key is. Set at least one of caKey, certKey or keyKey to a key your Secret holds, for example caKey: ca.crt." -}}
{{- end -}}
{{- if and $sslSecretKeys (not $sslSecret.name) -}}
{{- $errs = append $errs "database.ssl.existingSecret has a key set but no name. Set database.ssl.existingSecret.name to the Secret that holds the keys." -}}
{{- end -}}
{{- if and $sslSecret.certKey (not $sslSecret.keyKey) -}}
{{- $errs = append $errs "database.ssl.existingSecret.certKey is set but keyKey is not. A client certificate is only used with its private key." -}}
{{- end -}}
{{- if and $sslSecret.keyKey (not (or $sslSecret.certKey $ssl.cert)) -}}
{{- $errs = append $errs "database.ssl.existingSecret.keyKey is set but there is no client certificate. Set database.ssl.existingSecret.certKey, or database.ssl.cert." -}}
{{- end -}}
{{- if and (or $sslSecret.name $sslSecretKeys) (not $ssl.enabled) -}}
{{- $errs = append $errs "database.ssl.existingSecret is set but database.ssl.enabled is false. Set database.ssl.enabled: true, or remove database.ssl.existingSecret." -}}
{{- end -}}
{{- if and $ssl.ca $sslSecret.caKey -}}
{{- $errs = append $errs "database.ssl.ca and database.ssl.existingSecret.caKey are mutually exclusive. Use one or the other." -}}
{{- end -}}
{{- if and $ssl.cert $sslSecret.certKey -}}
{{- $errs = append $errs "database.ssl.cert and database.ssl.existingSecret.certKey are mutually exclusive. Use one or the other." -}}
{{- end -}}

{{/* --- Task runners --- */}}
{{- if and .Values.taskRunners.enabled (ne .Values.taskRunners.mode "external") -}}
{{- $errs = append $errs "taskRunners.mode must be 'external'. This chart only supports external task runner sidecars." -}}
{{- end -}}
{{- if and .Values.taskRunners.enabled ((.Values.taskRunners.probes | default dict).liveness | default dict).enabled -}}
{{- $healthPort := include "n8n.taskRunnerHealthCheckPort" . -}}
{{- if and $healthPort (or (not (regexMatch "^[0-9]+$" $healthPort)) (lt (atoi $healthPort) 1) (gt (atoi $healthPort) 65535)) -}}
{{- $errs = append $errs (printf "N8N_RUNNERS_LAUNCHER_HEALTH_CHECK_PORT in taskRunners.extraEnv must be a port number from 1 to 65535, got %q. The sidecar's liveness probe uses it." $healthPort) -}}
{{- end -}}
{{- end -}}
{{- /* A digest on one image only lets a chart upgrade move the other, so the
runner and n8n drift onto different versions. */ -}}
{{- if and .Values.taskRunners.enabled .Values.image.digest (not .Values.taskRunners.image.digest) -}}
{{- $errs = append $errs "image.digest is set but taskRunners.image.digest is not. Pin the runner image by digest too, from the same n8n version, or remove image.digest." -}}
{{- end -}}
{{- if and .Values.taskRunners.enabled .Values.taskRunners.image.digest (not .Values.image.digest) -}}
{{- $errs = append $errs "taskRunners.image.digest is set but image.digest is not. Pin the n8n image by digest too, from the same n8n version, or remove taskRunners.image.digest." -}}
{{- end -}}

{{/* --- Persistence --- */}}
{{- if and .Values.persistence.annotations .Values.persistence.existingClaim -}}
{{- $errs = append $errs (printf "persistence.annotations has no effect with persistence.existingClaim, because the chart does not create that PVC. Annotate %s directly, or remove persistence.annotations." .Values.persistence.existingClaim) -}}
{{- end -}}

{{/* --- S3 --- */}}
{{- if .Values.s3.enabled -}}
{{- if not .Values.s3.bucket.name -}}
{{- $errs = append $errs "s3.bucket.name is required when s3.enabled=true" -}}
{{- end -}}
{{- if not .Values.s3.bucket.region -}}
{{- $errs = append $errs "s3.bucket.region is required when s3.enabled=true" -}}
{{- end -}}
{{- if and (not .Values.s3.auth.autoDetect) (not .Values.s3.auth.accessKeyId) -}}
{{- $errs = append $errs "s3.auth.accessKeyId is required when s3.enabled=true and s3.auth.autoDetect=false" -}}
{{- end -}}
{{- if and .Values.s3.auth.autoDetect (not .Values.serviceAccount.awsRoleArn) -}}
{{- $errs = append $errs "serviceAccount.awsRoleArn is required when s3.auth.autoDetect=true (for IRSA)" -}}
{{- end -}}
{{- end -}}

{{/* --- License --- */}}
{{- if and .Values.license.enabled .Values.license.activationKey .Values.license.existingSecret.name -}}
{{- $errs = append $errs "license.activationKey and license.existingSecret.name are mutually exclusive. Use one or the other." -}}
{{- end -}}

{{/* --- Encryption key --- */}}
{{- $encryptionKeyFile := .Values.secretRefs.env.N8N_ENCRYPTION_KEY_FILE | default "" -}}
{{- if and $encryptionKeyFile (not (hasPrefix "/" $encryptionKeyFile)) -}}
{{- $errs = append $errs "secretRefs.env.N8N_ENCRYPTION_KEY_FILE must be an absolute path" -}}
{{- end -}}
{{- if and (not $encryptionKeyFile) (not .Values.secretRefs.existingSecret) (eq .Values.secretRefs.env.N8N_ENCRYPTION_KEY "change-me-to-a-long-random-key") -}}
{{- $errs = append $errs "secretRefs.env.N8N_ENCRYPTION_KEY must be changed from the default placeholder value, provide secretRefs.existingSecret with your own Secret, or set secretRefs.env.N8N_ENCRYPTION_KEY_FILE" -}}
{{- end -}}

{{/* --- Service account --- */}}
{{- if and (not .Values.serviceAccount.create) (eq .Values.serviceAccount.name "n8n") -}}
{{- $errs = append $errs "serviceAccount.create=false but serviceAccount.name is still the chart default \"n8n\". Set serviceAccount.name to your pre-existing ServiceAccount, or to \"\" to use the namespace's default ServiceAccount." -}}
{{- end -}}

{{/* --- Pod labels --- */}}
{{- $reservedPodLabels := list "app.kubernetes.io/name" "app.kubernetes.io/instance" "app.kubernetes.io/component" "app.kubernetes.io/version" "app.kubernetes.io/managed-by" "helm.sh/chart" -}}
{{- range $k, $v := (.Values.podLabels | default dict) -}}
{{- if has $k $reservedPodLabels -}}
{{- $errs = append $errs (printf "podLabels.%q is a chart-managed selector/identity label and cannot be overridden. Reserved keys: %s" $k (join ", " $reservedPodLabels)) -}}
{{- end -}}
{{- if not (kindIs "string" $v) -}}
{{- $errs = append $errs (printf "podLabels.%q must be a string (got %s). Kubernetes labels are map[string]string; quote numeric or boolean values, e.g. %q: \"true\"." $k (kindOf $v) $k) -}}
{{- end -}}
{{- end -}}

{{/* --- Extra objects --- */}}
{{- range $i, $entry := .Values.extraObjects -}}
{{- $rendered := include "n8n.extraObject" (dict "root" $ "object" $entry) -}}
{{- $obj := fromYaml $rendered -}}
{{/* fromYaml keeps only the first document, so a second one would be dropped without a word. */}}
{{- if regexMatch "(?m)^---" (trimPrefix "---" (trim $rendered)) -}}
{{- $errs = append $errs (printf "extraObjects[%d] holds more than one YAML document. Put each object in its own entry." $i) -}}
{{- else if hasKey $obj "Error" -}}
{{- $errs = append $errs (printf "extraObjects[%d] must render to a single Kubernetes object, as a map or a YAML string. %s" $i $obj.Error) -}}
{{- else if not (and $obj.apiVersion $obj.kind (dig "metadata" "name" "" $obj)) -}}
{{- $errs = append $errs (printf "extraObjects[%d] must set apiVersion, kind and metadata.name." $i) -}}
{{- end -}}
{{- end -}}

{{/* A single problem is reported as-is, so its message reads the same as the check wrote it. */}}
{{- if eq (len $errs) 1 -}}
{{- fail (first $errs) -}}
{{- else if $errs -}}
{{- fail (printf "%d problems in your values:\n- %s" (len $errs) (join "\n- " $errs)) -}}
{{- end -}}

{{- end -}}

{{/*
Task runners on main pods: only in standalone mode.
In queue mode, manual executions are offloaded to workers (OFFLOAD_MANUAL_EXECUTIONS_TO_WORKERS),
so workers handle code execution and main pods do not need runner sidecars.
*/}}
{{- define "n8n.mainTaskRunnersEnabled" -}}
{{- if and .Values.taskRunners.enabled (not .Values.queueMode.enabled) -}}true{{- end -}}
{{- end -}}

{{/*
The public editor URL, rendered as N8N_EDITOR_BASE_URL and printed by NOTES.txt.
editor.url wins. The ingress fallback uses https://, which assumes TLS ends at
the ingress or in front of it. Empty when no public URL is configured.
*/}}
{{- define "n8n.editorBaseUrl" -}}
{{- if .Values.editor.url -}}
{{ .Values.editor.url }}
{{- else if and .Values.ingress .Values.ingress.enabled (gt (len .Values.ingress.hosts) 0) -}}
https://{{ (index .Values.ingress.hosts 0).host }}
{{- else if and .Values.webhook.url (hasPrefix "http" (.Values.webhook.url | toString)) -}}
{{ .Values.webhook.url }}
{{- end -}}
{{- end -}}

{{/*
Whether KEDA will actually scale a component, and so whether a ScaledObject
renders for it. Empty triggers mean no scaler: KEDA requires spec.triggers and
rejects an object without them, so the chart renders none and the component
keeps the replica count it was given. That makes an empty trigger list the way
to run KEDA for one component and not the other.

Call with the root context and the component name, e.g.
  (dict "root" . "component" "worker")
*/}}
{{- define "n8n.kedaScalerEnabled" -}}
{{- $root := .root -}}
{{- if and $root.Values.keda.enabled $root.Values.queueMode.enabled -}}
{{- if eq .component "worker" -}}
{{- if and $root.Values.keda.worker.triggers (gt (int $root.Values.queueMode.workerReplicaCount) 0) -}}true{{- end -}}
{{- else if eq .component "webhook-processor" -}}
{{- if and $root.Values.keda.webhookProcessor.enabled $root.Values.webhookProcessor.enabled $root.Values.keda.webhookProcessor.triggers -}}true{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Whether an autoscaler owns a component's replica count, and so whether the
chart leaves spec.replicas off its Deployment and lets Kubernetes default it
to 1 on first create. KEDA owns the count wherever a ScaledObject renders,
and the built-in HPA owns it only whilst KEDA is off, since keda.enabled
replaces the worker and webhook HPAs.

Call with the root context and the component name, e.g.
  (dict "root" . "component" "worker")
*/}}
{{- define "n8n.autoscalerOwnsReplicas" -}}
{{- $root := .root -}}
{{- $hpaEnabled := ternary $root.Values.hpa.worker.enabled $root.Values.hpa.webhookProcessor.enabled (eq .component "worker") -}}
{{- if or (include "n8n.kedaScalerEnabled" .) (and $hpaEnabled (not $root.Values.keda.enabled)) -}}true{{- end -}}
{{- end -}}

{{/*
Annotation mapping for a KEDA ScaledObject: commonAnnotations with the
chart-managed pause annotations set over the top, so a user key can never
render twice. Renders nothing when there is nothing to annotate, so the
caller wraps it in `with` and writes the `annotations:` key itself.

Call with the root context and the keda.<component> values, e.g.
  (dict "root" . "componentValues" .Values.keda.worker)
*/}}
{{- define "n8n.kedaAnnotations" -}}
{{- $root := .root -}}
{{- $componentValues := .componentValues -}}
{{- $annotations := deepCopy ($root.Values.commonAnnotations | default dict) -}}
{{- if $componentValues.pause -}}
{{- $_ := set $annotations "autoscaling.keda.sh/paused" "true" -}}
{{/* 0 is falsy in Go templates, so unset has to be tested for by kind. */}}
{{- if not (kindIs "invalid" $componentValues.pausedReplicaCount) -}}
{{- $_ := set $annotations "autoscaling.keda.sh/paused-replicas" ($componentValues.pausedReplicaCount | toString) -}}
{{- end -}}
{{- end -}}
{{- if $annotations -}}
{{- toYaml $annotations -}}
{{- end -}}
{{- end -}}

{{/*
Main pod replica count: multiMain.replicas under multi-main, otherwise replicaCount.
*/}}
{{- define "n8n.mainReplicas" -}}
{{- ternary .Values.multiMain.replicas .Values.replicaCount .Values.multiMain.enabled -}}
{{- end -}}
